#Delayedflight's Outfit Pack

A couple of outfits that I cooked up for the human faction available mainly at the Kraz Outfitters and some lower tier stuff available throughout the common outfit stores.
I'm trying to balance them so feel free to give me feedback.


