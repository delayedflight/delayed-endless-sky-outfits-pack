Delayedflight's Outfit Pack

A couple of outfits that I cooked up for the human faction available mainly at the Kraz Outfitters and some lower tier stuff available throughout the common outfit stores. I'm trying to balance them so feel free to give me feedback.

These outfits include:

1 boarding outfit 
4 sizes of shield extension outfits (mainly to extend the viability of older ships or for people who want to use their favourite ship for longer) 
3 outfit space modification outfits